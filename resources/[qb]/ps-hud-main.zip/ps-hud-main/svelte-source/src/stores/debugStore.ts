const debugMode: boolean = false;
export default debugMode;